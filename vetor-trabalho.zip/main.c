#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

struct vetor{
    
    float *preco;
    int *ident;
    char *nome;
    int tam;
    int cap;
    int index;
    
};

typedef struct vetor Vetor;

Vetor *criar(int x, bool *DeuCerto){
    
    Vetor *v;
    
    v = (Vetor *) malloc (sizeof(Vetor));
    if(v != NULL){
        *DeuCerto = true;
        v->preco = (float *) malloc (x * sizeof(float));
        v->ident = (int *) malloc (x * sizeof(int));
        v->nome = (char *) malloc (x * sizeof(char));
        v->cap = x;
        v->tam = 0;
        v->index = 0;
    }
    
    else *DeuCerto = false;
    
    return v;
}

bool cheio(Vetor *v){
    
    if(v->tam == v->cap){
        
        return true;
    }
    
    else return false;
}

bool vazio(Vetor *v){
    
    if(v->tam == 0){
        return true;
    }
    else return false;
    
}

void inserir(Vetor *v, float x, char y){
    
    if(cheio(v) == false){
    
    v->preco[v->tam] = x;
    v->ident[v->tam] = v->index + 1;
    v->nome[v->tam] = y;
    v->tam = v->tam + 1;
    }

}

void mostrar(Vetor *v, float *x, int *z, char *y){
    

    
    if(vazio(v) == false){
        *x = v->preco[v->index];
        *z = v->index + 1;
        *y = v->nome[v->index];
        v->tam = v->tam - 1;
        v->index = v->index + 1;
    }
    
}

int main()
{
    
    bool deucerto;
    Vetor *v;
    float pr;
    int t, id;
    char n;
    
    printf("Digite o tamanho do cardapio: ");
    scanf("%d", &t);
    
    v = criar(t, &deucerto);
    
    
    for(int i = t; 0 < i; i--){
        
        printf("\nInsira um preco: ");
        scanf("%f", &pr);
        printf("\nInsira um nome: ");
        scanf(" %c", &n);
        inserir(v, pr, n);
        
    }
    
    for(int i = t; 0 < i; i--){
    mostrar(v, &pr, &id, &n);

    printf("Prato:\n");
    printf("%d- ", id);
    printf("%c ", n);
    printf("R$ %.2f\n\n", pr);
    
    }
    
    return 0;
}
