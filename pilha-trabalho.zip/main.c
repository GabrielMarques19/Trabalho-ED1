#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define TAM 10  //defini estaticamente um valor fixo para a pilha

struct pilha{
    char choco[TAM];  //tamanho da pilha
    int topo;         //variável para topo da pilha    
};

typedef struct pilha Pilha;

void criapl(Pilha *p){ //inicia o topo da pilha com um valor não utilizado, -1
        p->topo = -1;
    
}

bool vazia(Pilha *p){ //testa se pilha está vazia com o topo possuindo valor -1
        
    if(p-> topo == -1){
        return true;
    }
    else return false;
    
}

bool cheia(Pilha *p){ //testa se pilha está cheia usando o valor do topo atual
    
    if(p->topo = TAM - 1){
        return true;
    }
    else return false;
}

bool inserepl(Pilha *p, char *y){ //insere por referência um caractere na pilha
    
    bool DeuCerto; //variável para confirmar o sucesso ou fracasso da função
    
        p->topo++; //topo incrementado antes de ser utilizado
        p->choco[p->topo] = *y; //insere variável no topo
        DeuCerto = true;
        return DeuCerto;
    
}


bool removepl(Pilha *p, char *y){
    
    bool DeuCerto;
    
        *y = p->choco[p->topo]; //coloco variável que estava no topo em uma variável passada por referência
        p->topo--; //decremento topo da pilha após utilizá-lo
        DeuCerto = true;
        return true;
}

int main(){
    
    Pilha *p;
    char c, a;
    int i;
    
    criapl(p);
    
    for(i = 0; i < TAM; i ++){

        printf("Adicione um chocolate a pilha: ");
        scanf(" %c", &c);
        printf("\n");
        inserepl(p, &c);
    }
    
    for(i = 0; i < TAM; i++){
        
        printf("O chocolate removido foi: ");
        removepl(p, &a);
        printf("%c", a);
        printf("\n");
    }
    
    return 0;
}

